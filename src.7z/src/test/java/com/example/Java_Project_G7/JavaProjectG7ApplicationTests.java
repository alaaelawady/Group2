package com.example.Java_Project_G7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaProjectG7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
