package com.example.Java_Project_G7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaProjectG7Application {


	public static void main(String[] args) {

		SpringApplication.run(JavaProjectG7Application.class, args);



	}


}
